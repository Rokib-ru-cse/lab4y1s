## Topics:
  * Pure pursuit problem
  * Simulation of a chemical reactor
  * Random number generator using LCM
  * Random number generator using the built-in library functions 
  * Test of the uniformity property of some generated random numbers
  * (Runs Up-Down) Test of the independence property of some generated random numbers
  * (Runs Above-Below) Test of the independence property of some generated random numbers

