* compilation `g++ name.cpp -lpthread`
* run command  `./a.out 2(number of thread) 10000(total operations)`