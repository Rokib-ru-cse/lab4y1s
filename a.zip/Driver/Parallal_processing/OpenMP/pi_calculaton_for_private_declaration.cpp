/// giving wrong ans

#include<bits/stdc++.h>
#include<omp.h>


using namespace std;


int main(int argc, char * argv[]){

    int i, n,k;
    double sum, factor=1.0;

    int thread_count = strtol(argv[1],NULL,10);

    sum = 0.0;
    n = 1000;
    k=n/thread_count ;

    // this pragma is a pre processor which will start openmp code if we don't put this , then the programm will run as a seial code of cpp
    # pragma omp parallel num_threads(thread_count) \
        reduction(+ : sum)
        {
            #pragma parallel for
            for(i = 0 ; i <= k ; i++){

                sum += factor/(2.0 * (double)i + 1);
                factor=-factor;
            }
        }



    cout<<"PI : "<<sum * 4.0<<endl;

    return 0;
}
