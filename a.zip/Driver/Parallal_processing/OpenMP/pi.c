#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#define MAX_THREADS 8

static long steps = 1000000000;
double step;

int main (int argc, const char *argv[]) {

    int i,j;
    double factor=1.0;
    double pi, sum = 0.0;
    double start, delta;

    step = 1.0/(double) steps;


         start = omp_get_wtime();


        #pragma omp parallel for reduction(+:sum)

            for(i = 0 ; i <= steps; i++){

                sum += factor/(2.0 * (double)i + 1);
                factor=-factor;
            }

        // Out of the parallel region, finialize computation
        pi = 4* sum;

        printf("PI = %.16g computed in seconds\n", pi);




}
