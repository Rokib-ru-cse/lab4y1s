#include<stdio.h>
#include<unistd.h>
#include<pthread.h>

void* myturn(void * arg){
    int *iptr = (int*) arg;
    printf("*arg %d\n", *iptr);
    for(int j=0;j<5;j++){
        sleep(1);
        printf("my turn %d %d\n",j,(*iptr)++);
    }
}

void yourturn(){
    for(int j=0;j<5;j++){
        sleep(2);
        printf("your turn\n");
    }
}

int main(){

    pthread_t newthread;
    int v = 5;
    pthread_create(&newthread,NULL,myturn,&v);


    // myturn();
    yourturn();
    printf("after execution %d\n",v);
}