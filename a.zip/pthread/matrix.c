#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
//parallel specific variables;
long thread_count;
double a;
double b;
long int n; //number of trapezoidal
double h;
double global_sum;
int mat[10][10], vec[10], res[10];
int m, n;

//mutex dec
pthread_mutex_t mutex;

void *matrix(void *rank)
{
    long thread_rank = (long)rank;
    int i, j;
    int local_m = m / thread_count;

    int my_first_row = thread_rank * local_m;
    int my_last_row = (thread_rank + 1) * local_m - 1;
    
    for (i = my_first_row; i <= my_last_row; i++)
    {
        res[i] = 0.0;
        for (j = 0; j < n; j++)
        {
            res[i] += mat[i][j] * vec[j];
        }
    } 

    //update the global_sum;
    // pthread_mutex_lock(&mutex);
    // res[i] += mat[i][j] * vec[j];
    // pthread_mutex_unlock(&mutex);

    return NULL;
}

int main(int argc, char *argv[])
{
    thread_count = strtol(argv[1], NULL, 10);
    long thread;
    pthread_t *thread_handles;
    //create thread handles and initialize mutex;
    thread_handles = malloc(thread_count * sizeof(pthread_t));

    puts("enter matrix size");
    scanf("%d %d", &m, &n);

    puts("enter matrix");

    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            scanf("%d", &mat[i][j]);
        }
    }
    puts("enter vector");
    for (int j = 0; j < n; j++)
    {
        scanf("%d", &vec[j]);
    }

    clock_t begin = clock();

    for (thread = 0; thread < thread_count; thread++)
    {
        pthread_create(&thread_handles[thread], NULL, matrix, (void *)thread);
    }
    //join all the thread handles;
    for (thread = 0; thread < thread_count; thread++)
    {
        pthread_join(thread_handles[thread], NULL);
    }

    clock_t end = clock();

    //fre thread handles and mutex;

    free(thread_handles);
    pthread_mutex_destroy(&mutex);
    for (int j = 0; j < n; j++)
    {
        printf("%d \n", res[j]);
    }
    double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;

    printf("Total time: %.8lf\n", time_spent * 1000.0);

    return 0;
}