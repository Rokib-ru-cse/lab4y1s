#include<pthread.h>
#include<stdio.h>
#include<unistd.h>

void myturn(){
    while(1){
        sleep(1);
        printf("my turn\n");
    }
}

void* yourturn(void * arg){
    while(1){
        sleep(2);
        printf("your turn\n");
    }
    return NULL;
}



int main(){

    pthread_t newthread;
    pthread_create(&newthread,NULL,yourturn,NULL);
    myturn();
    // yourturn();
}