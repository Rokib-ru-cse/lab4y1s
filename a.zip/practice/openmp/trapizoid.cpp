#include <bits/stdc++.h>
#include <omp.h>
using namespace std;

double func(double x)
{
    return x * x;
}

double trapizoid(double a, double b, int n)
{
    double segment_area, tmp, start, end, height, local_n;
    int rank, thread_count, i;
    rank = omp_get_thread_num();
    thread_count = omp_get_num_threads();

    local_n = n / thread_count;
    height = (b - a) / (double)n;
    start = a + rank * height * local_n;
    end = start + height * local_n;
    segment_area = (func(start) + func(end) / 2.0);
    for (i = 1; i < local_n; i++)
    {
        segment_area += func(start + i * height);
    }
    segment_area *= height;
return segment_area;
}

int main(int argc, char *argv[])
{
    int n = 100000000;
    double a, b, total_area = 0.0;
    int thread_count = strtol(argv[1], NULL, 10);

    a = 2.0;
    b = 4.0;

#pragma omp parallel num_threads(thread_count)\
reduction(+:total_area)
    total_area +=trapizoid(a, b, n);
    cout << "total area = " << total_area << endl;

    return 0;
}