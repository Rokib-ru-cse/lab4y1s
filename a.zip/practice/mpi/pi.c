#include <stdio.h>
#include <mpi.h>

double pi(int start, int end)
{
    double sum = 0.0, tmp, factor;
    if (start % 2 == 0)
    {
        factor = 1.0;
    }
    else
    {
        factor = -1.0;
    }
    for (int i = start; i < end; i++,factor=-factor)
    {
        sum += (double)factor / (2 * i + 1);
    }
    return sum;
}

int main()
{
    int rank, comsz, local_a, local_b, local_n;
    double local_sum, total_sum;
    int n = 10000000;

    MPI_Init(NULL, NULL);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &comsz);

    double start = MPI_Wtime();

    local_n = n / comsz;

    local_a = rank * local_n;
    local_b = local_a + local_n;
    local_sum = pi(local_a, local_b);

    if (rank != 0)
    {
        MPI_Send(&local_sum, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
    }
    else
    {
        total_sum = local_sum;
        for (int i = 1; i < comsz; i++)
        {
            MPI_Recv(&local_sum, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            total_sum += local_sum;
        }
    }
double endt = MPI_Wtime();
    if (rank == 0)
    {

        printf("%.2f \n", 4.0 * total_sum);
        printf("time = %lf",endt-start);
    }
    MPI_Finalize();
    return 0;
}