#include <stdio.h>
#include <mpi.h>

double func(double x)
{
    return x * x;
}

double trapizoid(double start, double end, double local_n, double height)
{
    double segment_area;
    segment_area = (func(start) + func(end) / 2.0);
    for (int i = 1; i < local_n; i++)
    {
        segment_area += func(start + i * height);
    }
    segment_area *= height;
    return segment_area;
}

int main()
{
    int comsz, rank, a, b, local_n;
    double height, start, end, local_area, total_area;
    ;
    double n = 10000000;
    MPI_Init(NULL, NULL);
    MPI_Comm_size(MPI_COMM_WORLD, &comsz);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    if (rank == 0)
    {
        printf("enter starting point and ending point\n");
        scanf("%d %d", &a, &b);
    }
    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&a, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast(&b, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    
    height = (b - a) / (double)n;
    local_n = n / comsz;
    start = a + rank * local_n * height;
    end = start + local_n * height;
    local_area = trapizoid(start, end, local_n, height);

    // MPI_Reduce(&local_area,&total_area,1,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);
    MPI_Reduce(&local_area, &total_area, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    if (rank == 0)
    {
        printf("area is = %lf\n", total_area);
    }
    MPI_Finalize();
    return 0;
}
