#include <stdio.h>
#include <mpi.h>
#include<stdlib.h>
#define ll long long
int main()
{
    int comsz, rank;
    ll total_ele = 10000000, ele_perprocess;

    double start = MPI_Wtime();

    MPI_Init(NULL, NULL);
    MPI_Comm_size(MPI_COMM_WORLD, &comsz);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    ele_perprocess = total_ele / comsz;

    ll *local_random = (ll *)malloc(sizeof(ll) * total_ele);
    ll *random = NULL;

    if (rank == 0)
    {
        random = (ll *)malloc(sizeof(ll) * total_ele);
        for (int i = 0; i < total_ele; i++)
        {
            random[i] = rand() % total_ele;
        }
    }
    MPI_Scatter(random, ele_perprocess, MPI_LONG_LONG, local_random, ele_perprocess, MPI_LONG_LONG, 0, MPI_COMM_WORLD);

    long double avg = 0;
    for (int i = 0; i < ele_perprocess; i++)
    {
        avg += local_random[i];
    }
    avg /= (long double)total_ele;

    long double *collect_avg = NULL;
    if (rank = 0)
    {
        collect_avg = (long double*)malloc(sizeof(long double) * comsz);
    }

    MPI_Gather(&avg, 1, MPI_LONG_DOUBLE, collect_avg, 1, MPI_LONG_DOUBLE, 0, MPI_COMM_WORLD);

    if(rank==0){
        long double sum=0;
        for(int i=0;i<comsz;i++){
            sum+=collect_avg[i];
        }
        printf("total average = %Lf\n",sum);
    }
    double end = MPI_Wtime();

    printf("rank %d need %lf time\n",rank,end-start);

    free(collect_avg);
    free(random);
    free(local_random);
    MPI_Finalize();
    return 0;
}
