#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
long thread_count;
double local_area, total_area;
double n = 10000000.0;
double local_n;
int a, b;
double height;
int flag;
pthread_mutex_t mutex_variable;
double func(double x)
{
    return x * x;
}

void *trapizoid(void *rank)
{
    long thread_rank = (long)rank;
    local_n = n / (double)thread_count;
    height = (b - a) / n;
    double start = a + thread_rank * local_n * height;
    double end = start + local_n * height;
    // printf(" before local_n = %lf height = %lf local area %lf from thread %ld\n",local_n,height,local_area,thread_rank);
    pthread_mutex_lock(&mutex_variable);
    local_area = ((func(start) + func(end)) / 2.0);
    for (int i = 1; i < local_n; i++)
    {
        local_area += func(start + i * height);
    }
    //  printf(" after local_n = %lf height = %lf local area %lf from thread %ld\n",local_n,height,local_area,thread_rank);
    local_area *= height;
    total_area += local_area;
    pthread_mutex_unlock(&mutex_variable);

    // local_area *= height;
    // while (flag != thread_rank);
    // printf("local area =%lf of thread rank %ld\n",local_area,thread_rank);
    // total_area += local_area;
    // flag = (flag + 1) % thread_count;

    return NULL;
}

int main(int argc, char *argv[])
{
    long thread;

    total_area = 0.0;
    local_area = 0.0;
    thread_count = strtol(argv[1], NULL, 10);
    pthread_t *thread_handles;
    thread_handles = malloc(thread_count * sizeof(pthread_t));
    n = 100000;
    flag = 0;
    puts("enter the number starting point and ending point");
    scanf("%d %d", &a, &b);

    for (thread = 0; thread < thread_count; thread++)
    {
        pthread_create(&thread_handles[thread], NULL, trapizoid, (void *)thread);
    }
    for (thread = 0; thread < thread_count; thread++)
    {
        pthread_join(thread_handles[thread], NULL);
    }

    printf("the calculated area from point %d to point %d is = %lf\n", a, b, total_area);
}