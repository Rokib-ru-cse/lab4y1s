#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

int thread_count;
int mat[10][10], vec[10], res[10], m, n;
int flag = 0;
void *matrix(void *rank)
{
    long thread_rank = (long)rank;
    int localm = m / thread_count;
    int first_row = thread_rank * localm;
    int last_row = (thread_rank + 1) * localm - 1;
    for (int i = first_row; i <= last_row; i++)
    {
        res[i] = 0;
        for (int j = 0; j < n; j++)
        {
            res[i] += mat[i][j] * vec[j];
        }
        printf("from pthread %ld calculated value = %d \n", thread_rank, res[i]);
    }
    
    return NULL;
}

int main(int argc, char *argv[])
{
    long thread;
    thread_count = strtol(argv[1], NULL, 10);
    pthread_t *thread_handles;
    thread_handles = malloc(thread_count * sizeof(pthread_t));
    puts("enter matrix size");
    scanf("%d %d", &m, &n);

    puts("enter matrix");

    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            scanf("%d", &mat[i][j]);
        }
    }
    puts("enter vector");
    for (int j = 0; j < n; j++)
    {
        scanf("%d", &vec[j]);
    }

    

    //run some code

    clock_t start = clock();
    for (thread = 0; thread < thread_count; thread++)
    {
        pthread_create(&thread_handles[thread], NULL, matrix, (void *)thread);
    }
    for (thread = 0; thread < thread_count; thread++)
    {
        pthread_join(thread_handles[thread], NULL);
    }

    clock_t end = clock();
    double total_time = (double)(end-start)/CLOCKS_PER_SEC;
    printf("calculated time %e\n",total_time* 1000.0);
}