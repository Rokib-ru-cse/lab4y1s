#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>


int thread_count;
int n;
long my_n;
double sum;

void * pi(void* rank){
    long thread_rank = (long) rank;
    double factor;
    double local_sum = 0.0;
    long start = my_n * thread_rank;
    long end = start+my_n;

    if(start%2==0){
        factor = 1.0;
    }
    else{
        factor = -1.0;
    }
    for(int i=start;i<=end;i++,factor=-factor){
        local_sum +=factor/(2*i+1);
    }
    sum += local_sum;
    return NULL;
}

int main(int agrc,char* argv[]){
    long thread;
    sum = 0.0;
    thread_count = strtol(argv[1],NULL,10);
    n = strtol(argv[2],NULL,10);
    pthread_t *thread_handles;
    thread_handles = malloc(thread_count*sizeof(pthread_t));
    my_n = n/thread_count;

    for(thread=0;thread<thread_count;thread++){
        pthread_create(&thread_handles[thread],NULL,pi,(void *)thread);
    }
    for(thread=0;thread<thread_count;thread++){
        pthread_join(thread_handles[thread],NULL);
    }
    
    printf("value of pi %.8lf\n",4.0*sum);

    return 0;
}