#include<mpi.h>
#include<stdio.h>
int main(int agrc,char** argv){
    MPI_Init(NULL,NULL);

    int mpi_size;
    MPI_Comm_size(MPI_COMM_WORLD,&mpi_size);

    printf("comszzzzzzzzzz %d\n",mpi_size);

    int mpi_rank;
    MPI_Comm_rank(MPI_COMM_WORLD,&mpi_rank);

    char processor_name[MPI_MAX_PROCESSOR_NAME];
    int name_len;
    MPI_Get_processor_name(processor_name,&name_len);

    printf("hello world from processor %s , rank %d out of processor %d\n",processor_name,mpi_rank,mpi_size);

    MPI_Finalize();
    return 0;
}