
#include<bits/stdc++.h>
#include<mpi.h>
using namespace std;




double trapizoid(int left_end, int right_end){

    double sum=0.0,tmp,factor;
    int i;
    /*calculating area of trapizoid of two end point*/
   // cout<<"start - ";
 if( left_end %2==0){
        factor=1.0;
    }
    else{
        factor=-1.0;
    }

    for (i =  left_end; i < right_end; i++, factor=-factor){
     sum +=( double)factor/(2*i+1);
    }
    return sum;
}

int main(){
    int my_rank, comm_sz, n = 10000000, local_n,local_a, local_b;
    double  total_sum,local_sum;
    int source;

    MPI_Init(NULL,NULL);
    MPI_Comm_size(MPI_COMM_WORLD, &comm_sz);
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);

    //height = (b-a)/(double)n;
     double start = MPI_Wtime();
         cout<<start<<" "<<my_rank<<endl;
    local_n = n/comm_sz;
    local_a= my_rank*local_n;

    if(my_rank == comm_sz-1 && n%comm_sz != 0){
        local_n = n % comm_sz;  // while number of iteration is not divided by the process
    }

    local_b= local_a + local_n;

    local_sum = trapizoid(local_a,local_b);

    //cout<<my_rank<<endl;

    if(my_rank !=0){
        MPI_Send(&local_sum, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
        //cout<<"here"<<endl;
    }
    else{
        total_sum = local_sum;
        for(int i = 1 ; i < comm_sz; i++){
            MPI_Recv(&local_sum, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            total_sum += local_sum;
        }

        //printing output
      double endt=MPI_Wtime();
        printf("%.20f \n", 4.0*total_sum);
        cout<<endt-start<<endl;
    }

    MPI_Finalize();
    return 0;
}
