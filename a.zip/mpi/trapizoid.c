#include<stdio.h>
#include<mpi.h>


int main(){
    int myrank,commsz,n,localn;
    double a,b,height,local_left_point,local_right_point,local_area,total_area;

    MPI_Init(NULL,NULL);
    MPI_Comm_rank(MPI_COMM_WORLD,&myrank);
    MPI_Comm_size(MPI_COMM_WORLD,&commsz);

    if(myrank==0){
        puts("enter the number of porcess, starting point, ending point : ");
        scanf("%d %lf %lf",&n,&a,&b);
    }

    MPI_Bcast(&n,1,MPI_INT,0,MPI_COMM_WORLD);
    MPI_Bcast(&a,1,MPI_DOUBLE,0,MPI_COMM_WORLD);
    MPI_Bcast(&b,1,MPI_DOUBLE,0,MPI_COMM_WORLD);

    height = (b-a)/(double)n;

    localn = n/commsz;
    local_left_point = a+myrank*height*localn;
    local_right_point = local_left_point+height*localn;
    local_area = trapizoid(local_left_point,local_right_point,localn,height);

    MPI_Reduce(&local_area,&total_area,1,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);

    if(myrank==0){
        printf("with n = %d trapizoid . the intigral of point %f and %f = %.5f",n,a,b,total_area);
    }
    MPI_Finalize();
    return 0;


}
