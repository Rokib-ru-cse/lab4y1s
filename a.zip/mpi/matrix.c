#include <stdio.h>
#include <mpi.h>

int mat[4][4] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, vec[4] = {1, 1, 1, 1}, res[4];
int m = 4, n = 4;

void printmat()
{
    for (int j = 0; j < n; j++)
    {
        printf("%d \n", res[j]);
    }
}

void matrix(int first_index, int last_index, int rank)
{

    double* x;
    local_i,j;
    local_k=1;
    

    
}

int main(int argc, char **argv)
{
    int my_rank, comm_sz;

    MPI_Init(NULL, NULL);
    MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &comm_sz);

    // printf("comszzzzzzzzzzz = %d\n", comm_sz);

    // puts("enter matrix size\n");
    // scanf("%d %d", &m, &n);
    // for (int i = 0; i < m; i++)
    // {
    //     for (int j = 0; j < n; j++)
    //     {
    //         scanf("%d", &mat[i][j]);
    //     }
    // }
    // puts("enter vector\n");
    // for (int j = 0; j < n; j++)
    // {
    //     scanf("%d", &vec[j]);
    // }

    int first_index, last_index, local_m;
    local_m = m / comm_sz;
    first_index = my_rank * local_m;
    last_index = (my_rank + 1) * local_m - 1;
    matrix(first_index, last_index, my_rank);

    MPI_Allgather(mat, &total_area, 1, MPI_DOUBLE, MPI_SUM, 0,MPI_COMM_WORLD);


    printmat();
    return 0;
}
